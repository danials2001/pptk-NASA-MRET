.. _Get_Started_Guide:

Get Started with |short_name|
==============================

.. include:: intro_gsg.rst

.. include:: system_requirements.rst

.. include:: before_beginning_and_example.rst

.. include:: hybrid_cpu_support.rst

Find more
*********

See our `documentation <https://oneapi-src.github.io/oneTBB/>`_ to learn more about |short_name|.
